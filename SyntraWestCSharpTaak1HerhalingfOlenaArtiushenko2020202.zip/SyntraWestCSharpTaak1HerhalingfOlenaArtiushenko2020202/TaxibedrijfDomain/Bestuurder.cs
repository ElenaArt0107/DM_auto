﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxibedrijfDomain
{
    public class Bestuurder:Persoon
    {
        //prop nav
        public Taxi TaxiWagen { get; set; }

    }
}
