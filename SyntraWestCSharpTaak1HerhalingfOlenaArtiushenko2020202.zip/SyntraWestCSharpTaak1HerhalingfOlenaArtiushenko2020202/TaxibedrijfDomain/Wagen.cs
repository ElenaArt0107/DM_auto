﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxibedrijfDomain
{
    public class Wagen
    {
        public string Nummerplaat { get; set; }
    }
}
