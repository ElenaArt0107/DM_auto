﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxibedrijfDomain
{
    public class Persoon
    {
        public string Naam { get; set; }
        public string Familienaam { get; set; }

    }
}
