﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ArtiushenkoOlenaEindwerkKlassendiagram1
{
    public class EngineType
    {
        private string _engineType;

        public string TypeEngine
        {
            get { return _engineType; }
            set { _engineType = value; }
        }
    }
}
