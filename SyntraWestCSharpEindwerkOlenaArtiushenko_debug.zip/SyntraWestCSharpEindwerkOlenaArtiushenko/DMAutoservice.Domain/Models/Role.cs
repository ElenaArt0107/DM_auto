﻿using System;
using System.Collections.ObjectModel;
using System.Text;

namespace DMAutoservice.Domain.Models
{
    public enum Role
    {
        Customer,
        Admin

    }
}