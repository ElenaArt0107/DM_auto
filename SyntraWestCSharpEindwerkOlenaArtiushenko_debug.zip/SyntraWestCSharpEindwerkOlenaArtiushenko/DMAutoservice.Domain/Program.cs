﻿using System;

namespace DMAutoservice.Domain
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
