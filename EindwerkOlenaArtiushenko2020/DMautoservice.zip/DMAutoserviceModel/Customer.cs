﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DMAutoserviceModel
{
    public class Customer:Person

    {
    }
}
