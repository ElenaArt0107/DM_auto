﻿using System;
using System.Collections.ObjectModel;
using System.Text;

namespace DMAutoserviceModel
{
    public enum Options
    {
        Chiptuning,
        ErrorCodesRemoval,
        LaunchControl,
        PropBang,
        CracleFolder,
        StartStopSutdown,
        Decat,
        SwirlFlaps,
        Vamx,
        Antilag

    }

}