﻿using System;
using System.Collections.ObjectModel;
using System.Text;

namespace DMAutoserviceModel
{
    public enum Role
    {
        User,
        Owner

    }
}