﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class Auto
    {
        public int Id { get; set; }
        public decimal Prijs { get; set; }
        public string Kleur { get; set; }
    }
}
